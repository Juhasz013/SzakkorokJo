<template>
  <main class="my-container">
    <h1>Szakkörök</h1>
    <div class="row">



        <div class="info-box col-md-5">
          <table class="table my-table">
            <thead>
              <tr>
                <th scope="col">Diák</th>
                <th scope="col">Osztály</th>
                <th scope="col">Szakkör</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="tanulo in tanulok" :key="tanulo.id">
                <td>{{ tanulo.nev }}</td>
                <td>{{ tanulo.osztaly }}</td>
                <td>
                  <select class="form-select" v-model="tanulo.szakkorId">
                    <option
                      v-for="szakkor in szakkorok"
                      :key="szakkor.id"
                      :value="szakkor.id"
                    >
                      {{ szakkor.nev }}
                    </option>
                  </select>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        
        <div class="col-md-6">
          <Card
            v-for="(szakkor, i) in szakkorok"
            :key="i"
            :szakkor="szakkor"
            :tanulok="tanulok"
          />
        </div>


      </div>
  </main>
</template>

<script>
import Card from "@/components/Card.vue";
export default {
  components: {
    Card,
  },
  data() {
    return {
      tanulok: [
        { id: 1, nev: "Lars Johansen", osztaly: "13.B", szakkorId: 5 },
        { id: 2, nev: "Ingrid Haugland", osztaly: "9.C", szakkorId: 5 },
        { id: 3, nev: "Ole Nilsen", osztaly: "13.D", szakkorId: 5 },
        { id: 4, nev: "TSigrid Bjørnsen", osztaly: "10.D", szakkorId: 5 },
        { id: 5, nev: "Erik Andersen", osztaly: "11.H", szakkorId: 5 },
        { id: 6, nev: "Solveig Haugen", osztaly: "13.F", szakkorId: 5 },
        { id: 7, nev: "Magnus Lund", osztaly: "9.F", szakkorId: 5 },
        { id: 8, nev: "Hakon Kristoffersen", osztaly: "12.D", szakkorId: 5 },
        { id: 9, nev: "Kari Pedersen", osztaly: "10.C", szakkorId: 5 },
        { id: 10, nev: "Bjørn Halvorsen", osztaly: "12.G", szakkorId: 5 },
      ],
      szakkorok: [
        { id: 1, nev: "Football" },
        { id: 2, nev: "Dráma" },
        { id: 3, nev: "Okkultatív" },
        { id: 4, nev: "Kertészet" },
        { id: 5, nev: "Nincs szakköre" },
      ],
      szakkorFeladatok: {
        Football: [],
        Dráma: [],
        Okkultatív: [],
        Kertészet: [],
      },
    };
  },
  computed: {
    nincsSzakkor() {
      return this.tanulok
        .filter((tanulo) => tanulo.szakkorId === 5)
        .map((tanulo) => tanulo.nev);
    },
  },
  watch: {
    tanulok: {
      handler() {
        this.updateSzakkorFeladatok();
      },
      deep: true,
    },
  },
  methods: {
    updateSzakkorFeladatok() {
      this.szakkorFeladatok = {
        Football: [],
        Dráma: [],
        Okkultatív: [],
        Kertészet: [],
      };

      this.tanulok.forEach((tanulo) => {
        if (tanulo.szakkorId !== 5) {
          const szakkorNev = this.szakkorok.find(
            (szakkor) => szakkor.id === tanulo.szakkorId
          ).nev;
          this.szakkorFeladatok[szakkorNev].push(tanulo.nev);
        }
      });
    },
  },
};
</script>


<style scoped>
.my-container {
  background-image: url("https://bilum.hu/wp-content/uploads/2020/12/34_lilla.png");
  background-size: cover;
  background-position: center;
  padding: 30px;
  min-height: 100vh;
}

.my-table {
  margin-top: 10px;
  border-radius: 10px;
  overflow: hidden;
  border: var(--text-color);
}


/* .row {
  background-color: rgba(0, 0, 0, 0.7);
  padding: 20px;
  border-radius: 15px;
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
} */

h1 {
  text-align: center;
  color: purple;
}

h1:hover {
  animation: moveSideToSide 0.5s ease-in-out infinite alternate;
}

/* .split {
  display: flex;
} */

/* .left {
  flex: 40%;
  margin-right: 20px;
  padding-right: 10px;
}

.right {
  flex: 60%;
  display: flex;
  flex-wrap: wrap;
} */

.szakkor-card {
  flex: 1 1 calc(50% - 20px);
  margin: 10px;
  border: 3px solid #000;
  border-radius: 10px;
  padding: 15px;
  box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.2);
  background-color: #f9f9f9;
  background-image: linear-gradient(to bottom right, #8a2be2, #d8bfd8);
}

.szakkor-card h5 {
  font-size: 1.2em;
  margin-bottom: 10px;
}
</style>
